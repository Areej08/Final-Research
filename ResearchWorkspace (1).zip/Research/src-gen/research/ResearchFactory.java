/**
 */
package research;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see research.ResearchPackage
 * @generated
 */
public interface ResearchFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ResearchFactory eINSTANCE = research.impl.ResearchFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Mobile Screen</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mobile Screen</em>'.
	 * @generated
	 */
	MobileScreen createMobileScreen();

	/**
	 * Returns a new object of class '<em>product Information</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>product Information</em>'.
	 * @generated
	 */
	productInformation createproductInformation();

	/**
	 * Returns a new object of class '<em>Picture</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Picture</em>'.
	 * @generated
	 */
	Picture createPicture();

	/**
	 * Returns a new object of class '<em>staff</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>staff</em>'.
	 * @generated
	 */
	staff createstaff();

	/**
	 * Returns a new object of class '<em>Camera</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Camera</em>'.
	 * @generated
	 */
	Camera createCamera();

	/**
	 * Returns a new object of class '<em>Eyes Filter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Eyes Filter</em>'.
	 * @generated
	 */
	EyesFilter createEyesFilter();

	/**
	 * Returns a new object of class '<em>Lip Filter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Lip Filter</em>'.
	 * @generated
	 */
	LipFilter createLipFilter();

	/**
	 * Returns a new object of class '<em>Full Make Up</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Full Make Up</em>'.
	 * @generated
	 */
	FullMakeUp createFullMakeUp();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ResearchPackage getResearchPackage();

} //ResearchFactory
