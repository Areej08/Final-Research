/**
 */
package research;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Full Make Up</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see research.ResearchPackage#getFullMakeUp()
 * @model
 * @generated
 */
public interface FullMakeUp extends Filters {
} // FullMakeUp
