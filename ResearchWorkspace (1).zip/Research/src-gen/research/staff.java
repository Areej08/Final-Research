/**
 */
package research;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>staff</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research.staff#getStaffName <em>Staff Name</em>}</li>
 * </ul>
 *
 * @see research.ResearchPackage#getstaff()
 * @model
 * @generated
 */
public interface staff extends EObject {
	/**
	 * Returns the value of the '<em><b>Staff Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Staff Name</em>' attribute.
	 * @see #setStaffName(String)
	 * @see research.ResearchPackage#getstaff_StaffName()
	 * @model
	 * @generated
	 */
	String getStaffName();

	/**
	 * Sets the value of the '{@link research.staff#getStaffName <em>Staff Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Staff Name</em>' attribute.
	 * @see #getStaffName()
	 * @generated
	 */
	void setStaffName(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void CheckCustomerReq();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void CheckPicture();

} // staff
