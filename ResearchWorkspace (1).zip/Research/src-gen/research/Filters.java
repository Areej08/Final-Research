/**
 */
package research;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Filters</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research.Filters#getFiltername <em>Filtername</em>}</li>
 *   <li>{@link research.Filters#getProductinformation <em>Productinformation</em>}</li>
 *   <li>{@link research.Filters#getCamera <em>Camera</em>}</li>
 * </ul>
 *
 * @see research.ResearchPackage#getFilters()
 * @model abstract="true"
 * @generated
 */
public interface Filters extends EObject {
	/**
	 * Returns the value of the '<em><b>Filtername</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Filtername</em>' attribute.
	 * @see #setFiltername(String)
	 * @see research.ResearchPackage#getFilters_Filtername()
	 * @model
	 * @generated
	 */
	String getFiltername();

	/**
	 * Sets the value of the '{@link research.Filters#getFiltername <em>Filtername</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Filtername</em>' attribute.
	 * @see #getFiltername()
	 * @generated
	 */
	void setFiltername(String value);

	/**
	 * Returns the value of the '<em><b>Productinformation</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link research.productInformation#getFilters <em>Filters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Productinformation</em>' reference.
	 * @see #setProductinformation(productInformation)
	 * @see research.ResearchPackage#getFilters_Productinformation()
	 * @see research.productInformation#getFilters
	 * @model opposite="filters"
	 * @generated
	 */
	productInformation getProductinformation();

	/**
	 * Sets the value of the '{@link research.Filters#getProductinformation <em>Productinformation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Productinformation</em>' reference.
	 * @see #getProductinformation()
	 * @generated
	 */
	void setProductinformation(productInformation value);

	/**
	 * Returns the value of the '<em><b>Camera</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link research.Camera#getFilters <em>Filters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Camera</em>' reference.
	 * @see #setCamera(Camera)
	 * @see research.ResearchPackage#getFilters_Camera()
	 * @see research.Camera#getFilters
	 * @model opposite="filters"
	 * @generated
	 */
	Camera getCamera();

	/**
	 * Sets the value of the '{@link research.Filters#getCamera <em>Camera</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Camera</em>' reference.
	 * @see #getCamera()
	 * @generated
	 */
	void setCamera(Camera value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void tryFilter();

} // Filters
