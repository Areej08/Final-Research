/**
 */
package research;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>product Information</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research.productInformation#getBrand <em>Brand</em>}</li>
 *   <li>{@link research.productInformation#getFoundationcolor <em>Foundationcolor</em>}</li>
 *   <li>{@link research.productInformation#getLipstickcolor <em>Lipstickcolor</em>}</li>
 *   <li>{@link research.productInformation#getPrice <em>Price</em>}</li>
 *   <li>{@link research.productInformation#getFilters <em>Filters</em>}</li>
 * </ul>
 *
 * @see research.ResearchPackage#getproductInformation()
 * @model
 * @generated
 */
public interface productInformation extends EObject {
	/**
	 * Returns the value of the '<em><b>Brand</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Brand</em>' attribute.
	 * @see #setBrand(String)
	 * @see research.ResearchPackage#getproductInformation_Brand()
	 * @model
	 * @generated
	 */
	String getBrand();

	/**
	 * Sets the value of the '{@link research.productInformation#getBrand <em>Brand</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Brand</em>' attribute.
	 * @see #getBrand()
	 * @generated
	 */
	void setBrand(String value);

	/**
	 * Returns the value of the '<em><b>Foundationcolor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Foundationcolor</em>' attribute.
	 * @see #setFoundationcolor(String)
	 * @see research.ResearchPackage#getproductInformation_Foundationcolor()
	 * @model
	 * @generated
	 */
	String getFoundationcolor();

	/**
	 * Sets the value of the '{@link research.productInformation#getFoundationcolor <em>Foundationcolor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Foundationcolor</em>' attribute.
	 * @see #getFoundationcolor()
	 * @generated
	 */
	void setFoundationcolor(String value);

	/**
	 * Returns the value of the '<em><b>Lipstickcolor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lipstickcolor</em>' attribute.
	 * @see #setLipstickcolor(String)
	 * @see research.ResearchPackage#getproductInformation_Lipstickcolor()
	 * @model
	 * @generated
	 */
	String getLipstickcolor();

	/**
	 * Sets the value of the '{@link research.productInformation#getLipstickcolor <em>Lipstickcolor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lipstickcolor</em>' attribute.
	 * @see #getLipstickcolor()
	 * @generated
	 */
	void setLipstickcolor(String value);

	/**
	 * Returns the value of the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Price</em>' attribute.
	 * @see #setPrice(int)
	 * @see research.ResearchPackage#getproductInformation_Price()
	 * @model
	 * @generated
	 */
	int getPrice();

	/**
	 * Sets the value of the '{@link research.productInformation#getPrice <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Price</em>' attribute.
	 * @see #getPrice()
	 * @generated
	 */
	void setPrice(int value);

	/**
	 * Returns the value of the '<em><b>Filters</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link research.Filters#getProductinformation <em>Productinformation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Filters</em>' reference.
	 * @see #setFilters(Filters)
	 * @see research.ResearchPackage#getproductInformation_Filters()
	 * @see research.Filters#getProductinformation
	 * @model opposite="productinformation"
	 * @generated
	 */
	Filters getFilters();

	/**
	 * Sets the value of the '{@link research.productInformation#getFilters <em>Filters</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Filters</em>' reference.
	 * @see #getFilters()
	 * @generated
	 */
	void setFilters(Filters value);

} // productInformation
