/**
 */
package research.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import research.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see research.ResearchPackage
 * @generated
 */
public class ResearchAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ResearchPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ResearchAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = ResearchPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ResearchSwitch<Adapter> modelSwitch = new ResearchSwitch<Adapter>() {
		@Override
		public Adapter caseMobileScreen(MobileScreen object) {
			return createMobileScreenAdapter();
		}

		@Override
		public Adapter caseFilters(Filters object) {
			return createFiltersAdapter();
		}

		@Override
		public Adapter caseproductInformation(productInformation object) {
			return createproductInformationAdapter();
		}

		@Override
		public Adapter casePicture(Picture object) {
			return createPictureAdapter();
		}

		@Override
		public Adapter casestaff(staff object) {
			return createstaffAdapter();
		}

		@Override
		public Adapter caseCamera(Camera object) {
			return createCameraAdapter();
		}

		@Override
		public Adapter caseEyesFilter(EyesFilter object) {
			return createEyesFilterAdapter();
		}

		@Override
		public Adapter caseLipFilter(LipFilter object) {
			return createLipFilterAdapter();
		}

		@Override
		public Adapter caseFullMakeUp(FullMakeUp object) {
			return createFullMakeUpAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link research.MobileScreen <em>Mobile Screen</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see research.MobileScreen
	 * @generated
	 */
	public Adapter createMobileScreenAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link research.Filters <em>Filters</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see research.Filters
	 * @generated
	 */
	public Adapter createFiltersAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link research.productInformation <em>product Information</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see research.productInformation
	 * @generated
	 */
	public Adapter createproductInformationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link research.Picture <em>Picture</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see research.Picture
	 * @generated
	 */
	public Adapter createPictureAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link research.staff <em>staff</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see research.staff
	 * @generated
	 */
	public Adapter createstaffAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link research.Camera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see research.Camera
	 * @generated
	 */
	public Adapter createCameraAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link research.EyesFilter <em>Eyes Filter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see research.EyesFilter
	 * @generated
	 */
	public Adapter createEyesFilterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link research.LipFilter <em>Lip Filter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see research.LipFilter
	 * @generated
	 */
	public Adapter createLipFilterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link research.FullMakeUp <em>Full Make Up</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see research.FullMakeUp
	 * @generated
	 */
	public Adapter createFullMakeUpAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //ResearchAdapterFactory
