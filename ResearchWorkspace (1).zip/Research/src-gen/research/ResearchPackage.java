/**
 */
package research;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see research.ResearchFactory
 * @model kind="package"
 * @generated
 */
public interface ResearchPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "research";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/research";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "research";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ResearchPackage eINSTANCE = research.impl.ResearchPackageImpl.init();

	/**
	 * The meta object id for the '{@link research.impl.MobileScreenImpl <em>Mobile Screen</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research.impl.MobileScreenImpl
	 * @see research.impl.ResearchPackageImpl#getMobileScreen()
	 * @generated
	 */
	int MOBILE_SCREEN = 0;

	/**
	 * The feature id for the '<em><b>Productinformation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_SCREEN__PRODUCTINFORMATION = 0;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_SCREEN__CAMERA = 1;

	/**
	 * The feature id for the '<em><b>Staff</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_SCREEN__STAFF = 2;

	/**
	 * The feature id for the '<em><b>Filters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_SCREEN__FILTERS = 3;

	/**
	 * The feature id for the '<em><b>Picture</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_SCREEN__PICTURE = 4;

	/**
	 * The number of structural features of the '<em>Mobile Screen</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_SCREEN_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Mobile Screen</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_SCREEN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research.impl.FiltersImpl <em>Filters</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research.impl.FiltersImpl
	 * @see research.impl.ResearchPackageImpl#getFilters()
	 * @generated
	 */
	int FILTERS = 1;

	/**
	 * The feature id for the '<em><b>Filtername</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERS__FILTERNAME = 0;

	/**
	 * The feature id for the '<em><b>Productinformation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERS__PRODUCTINFORMATION = 1;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERS__CAMERA = 2;

	/**
	 * The number of structural features of the '<em>Filters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERS_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Try Filter</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERS___TRY_FILTER = 0;

	/**
	 * The number of operations of the '<em>Filters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILTERS_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link research.impl.productInformationImpl <em>product Information</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research.impl.productInformationImpl
	 * @see research.impl.ResearchPackageImpl#getproductInformation()
	 * @generated
	 */
	int PRODUCT_INFORMATION = 2;

	/**
	 * The feature id for the '<em><b>Brand</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_INFORMATION__BRAND = 0;

	/**
	 * The feature id for the '<em><b>Foundationcolor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_INFORMATION__FOUNDATIONCOLOR = 1;

	/**
	 * The feature id for the '<em><b>Lipstickcolor</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_INFORMATION__LIPSTICKCOLOR = 2;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_INFORMATION__PRICE = 3;

	/**
	 * The feature id for the '<em><b>Filters</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_INFORMATION__FILTERS = 4;

	/**
	 * The number of structural features of the '<em>product Information</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_INFORMATION_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>product Information</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_INFORMATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research.impl.PictureImpl <em>Picture</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research.impl.PictureImpl
	 * @see research.impl.ResearchPackageImpl#getPicture()
	 * @generated
	 */
	int PICTURE = 3;

	/**
	 * The feature id for the '<em><b>Send Pictures</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICTURE__SEND_PICTURES = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICTURE__NAME = 1;

	/**
	 * The number of structural features of the '<em>Picture</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICTURE_FEATURE_COUNT = 2;

	/**
	 * The operation id for the '<em>Click Picture</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICTURE___CLICK_PICTURE = 0;

	/**
	 * The operation id for the '<em>Save</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICTURE___SAVE = 1;

	/**
	 * The operation id for the '<em>Send</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICTURE___SEND = 2;

	/**
	 * The number of operations of the '<em>Picture</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PICTURE_OPERATION_COUNT = 3;

	/**
	 * The meta object id for the '{@link research.impl.staffImpl <em>staff</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research.impl.staffImpl
	 * @see research.impl.ResearchPackageImpl#getstaff()
	 * @generated
	 */
	int STAFF = 4;

	/**
	 * The feature id for the '<em><b>Staff Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF__STAFF_NAME = 0;

	/**
	 * The number of structural features of the '<em>staff</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF_FEATURE_COUNT = 1;

	/**
	 * The operation id for the '<em>Check Customer Req</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF___CHECK_CUSTOMER_REQ = 0;

	/**
	 * The operation id for the '<em>Check Picture</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF___CHECK_PICTURE = 1;

	/**
	 * The number of operations of the '<em>staff</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STAFF_OPERATION_COUNT = 2;

	/**
	 * The meta object id for the '{@link research.impl.CameraImpl <em>Camera</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research.impl.CameraImpl
	 * @see research.impl.ResearchPackageImpl#getCamera()
	 * @generated
	 */
	int CAMERA = 5;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__CAMERA = 0;

	/**
	 * The feature id for the '<em><b>Resolution</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__RESOLUTION = 1;

	/**
	 * The feature id for the '<em><b>Picture</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__PICTURE = 2;

	/**
	 * The feature id for the '<em><b>Filters</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__FILTERS = 3;

	/**
	 * The number of structural features of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link research.impl.EyesFilterImpl <em>Eyes Filter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research.impl.EyesFilterImpl
	 * @see research.impl.ResearchPackageImpl#getEyesFilter()
	 * @generated
	 */
	int EYES_FILTER = 6;

	/**
	 * The feature id for the '<em><b>Filtername</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EYES_FILTER__FILTERNAME = FILTERS__FILTERNAME;

	/**
	 * The feature id for the '<em><b>Productinformation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EYES_FILTER__PRODUCTINFORMATION = FILTERS__PRODUCTINFORMATION;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EYES_FILTER__CAMERA = FILTERS__CAMERA;

	/**
	 * The number of structural features of the '<em>Eyes Filter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EYES_FILTER_FEATURE_COUNT = FILTERS_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Try Filter</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EYES_FILTER___TRY_FILTER = FILTERS___TRY_FILTER;

	/**
	 * The number of operations of the '<em>Eyes Filter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EYES_FILTER_OPERATION_COUNT = FILTERS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link research.impl.LipFilterImpl <em>Lip Filter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research.impl.LipFilterImpl
	 * @see research.impl.ResearchPackageImpl#getLipFilter()
	 * @generated
	 */
	int LIP_FILTER = 7;

	/**
	 * The feature id for the '<em><b>Filtername</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIP_FILTER__FILTERNAME = FILTERS__FILTERNAME;

	/**
	 * The feature id for the '<em><b>Productinformation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIP_FILTER__PRODUCTINFORMATION = FILTERS__PRODUCTINFORMATION;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIP_FILTER__CAMERA = FILTERS__CAMERA;

	/**
	 * The number of structural features of the '<em>Lip Filter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIP_FILTER_FEATURE_COUNT = FILTERS_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Try Filter</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIP_FILTER___TRY_FILTER = FILTERS___TRY_FILTER;

	/**
	 * The number of operations of the '<em>Lip Filter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIP_FILTER_OPERATION_COUNT = FILTERS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link research.impl.FullMakeUpImpl <em>Full Make Up</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see research.impl.FullMakeUpImpl
	 * @see research.impl.ResearchPackageImpl#getFullMakeUp()
	 * @generated
	 */
	int FULL_MAKE_UP = 8;

	/**
	 * The feature id for the '<em><b>Filtername</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FULL_MAKE_UP__FILTERNAME = FILTERS__FILTERNAME;

	/**
	 * The feature id for the '<em><b>Productinformation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FULL_MAKE_UP__PRODUCTINFORMATION = FILTERS__PRODUCTINFORMATION;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FULL_MAKE_UP__CAMERA = FILTERS__CAMERA;

	/**
	 * The number of structural features of the '<em>Full Make Up</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FULL_MAKE_UP_FEATURE_COUNT = FILTERS_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Try Filter</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FULL_MAKE_UP___TRY_FILTER = FILTERS___TRY_FILTER;

	/**
	 * The number of operations of the '<em>Full Make Up</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FULL_MAKE_UP_OPERATION_COUNT = FILTERS_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link research.MobileScreen <em>Mobile Screen</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mobile Screen</em>'.
	 * @see research.MobileScreen
	 * @generated
	 */
	EClass getMobileScreen();

	/**
	 * Returns the meta object for the containment reference list '{@link research.MobileScreen#getProductinformation <em>Productinformation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Productinformation</em>'.
	 * @see research.MobileScreen#getProductinformation()
	 * @see #getMobileScreen()
	 * @generated
	 */
	EReference getMobileScreen_Productinformation();

	/**
	 * Returns the meta object for the containment reference list '{@link research.MobileScreen#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Camera</em>'.
	 * @see research.MobileScreen#getCamera()
	 * @see #getMobileScreen()
	 * @generated
	 */
	EReference getMobileScreen_Camera();

	/**
	 * Returns the meta object for the containment reference list '{@link research.MobileScreen#getStaff <em>Staff</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Staff</em>'.
	 * @see research.MobileScreen#getStaff()
	 * @see #getMobileScreen()
	 * @generated
	 */
	EReference getMobileScreen_Staff();

	/**
	 * Returns the meta object for the containment reference list '{@link research.MobileScreen#getFilters <em>Filters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Filters</em>'.
	 * @see research.MobileScreen#getFilters()
	 * @see #getMobileScreen()
	 * @generated
	 */
	EReference getMobileScreen_Filters();

	/**
	 * Returns the meta object for the containment reference list '{@link research.MobileScreen#getPicture <em>Picture</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Picture</em>'.
	 * @see research.MobileScreen#getPicture()
	 * @see #getMobileScreen()
	 * @generated
	 */
	EReference getMobileScreen_Picture();

	/**
	 * Returns the meta object for class '{@link research.Filters <em>Filters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Filters</em>'.
	 * @see research.Filters
	 * @generated
	 */
	EClass getFilters();

	/**
	 * Returns the meta object for the attribute '{@link research.Filters#getFiltername <em>Filtername</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Filtername</em>'.
	 * @see research.Filters#getFiltername()
	 * @see #getFilters()
	 * @generated
	 */
	EAttribute getFilters_Filtername();

	/**
	 * Returns the meta object for the reference '{@link research.Filters#getProductinformation <em>Productinformation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Productinformation</em>'.
	 * @see research.Filters#getProductinformation()
	 * @see #getFilters()
	 * @generated
	 */
	EReference getFilters_Productinformation();

	/**
	 * Returns the meta object for the reference '{@link research.Filters#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Camera</em>'.
	 * @see research.Filters#getCamera()
	 * @see #getFilters()
	 * @generated
	 */
	EReference getFilters_Camera();

	/**
	 * Returns the meta object for the '{@link research.Filters#tryFilter() <em>Try Filter</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Try Filter</em>' operation.
	 * @see research.Filters#tryFilter()
	 * @generated
	 */
	EOperation getFilters__TryFilter();

	/**
	 * Returns the meta object for class '{@link research.productInformation <em>product Information</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>product Information</em>'.
	 * @see research.productInformation
	 * @generated
	 */
	EClass getproductInformation();

	/**
	 * Returns the meta object for the attribute '{@link research.productInformation#getBrand <em>Brand</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Brand</em>'.
	 * @see research.productInformation#getBrand()
	 * @see #getproductInformation()
	 * @generated
	 */
	EAttribute getproductInformation_Brand();

	/**
	 * Returns the meta object for the attribute '{@link research.productInformation#getFoundationcolor <em>Foundationcolor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Foundationcolor</em>'.
	 * @see research.productInformation#getFoundationcolor()
	 * @see #getproductInformation()
	 * @generated
	 */
	EAttribute getproductInformation_Foundationcolor();

	/**
	 * Returns the meta object for the attribute '{@link research.productInformation#getLipstickcolor <em>Lipstickcolor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Lipstickcolor</em>'.
	 * @see research.productInformation#getLipstickcolor()
	 * @see #getproductInformation()
	 * @generated
	 */
	EAttribute getproductInformation_Lipstickcolor();

	/**
	 * Returns the meta object for the attribute '{@link research.productInformation#getPrice <em>Price</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Price</em>'.
	 * @see research.productInformation#getPrice()
	 * @see #getproductInformation()
	 * @generated
	 */
	EAttribute getproductInformation_Price();

	/**
	 * Returns the meta object for the reference '{@link research.productInformation#getFilters <em>Filters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Filters</em>'.
	 * @see research.productInformation#getFilters()
	 * @see #getproductInformation()
	 * @generated
	 */
	EReference getproductInformation_Filters();

	/**
	 * Returns the meta object for class '{@link research.Picture <em>Picture</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Picture</em>'.
	 * @see research.Picture
	 * @generated
	 */
	EClass getPicture();

	/**
	 * Returns the meta object for the reference list '{@link research.Picture#getSendPictures <em>Send Pictures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Send Pictures</em>'.
	 * @see research.Picture#getSendPictures()
	 * @see #getPicture()
	 * @generated
	 */
	EReference getPicture_SendPictures();

	/**
	 * Returns the meta object for the attribute '{@link research.Picture#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see research.Picture#getName()
	 * @see #getPicture()
	 * @generated
	 */
	EAttribute getPicture_Name();

	/**
	 * Returns the meta object for the '{@link research.Picture#ClickPicture() <em>Click Picture</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Click Picture</em>' operation.
	 * @see research.Picture#ClickPicture()
	 * @generated
	 */
	EOperation getPicture__ClickPicture();

	/**
	 * Returns the meta object for the '{@link research.Picture#Save() <em>Save</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Save</em>' operation.
	 * @see research.Picture#Save()
	 * @generated
	 */
	EOperation getPicture__Save();

	/**
	 * Returns the meta object for the '{@link research.Picture#Send() <em>Send</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Send</em>' operation.
	 * @see research.Picture#Send()
	 * @generated
	 */
	EOperation getPicture__Send();

	/**
	 * Returns the meta object for class '{@link research.staff <em>staff</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>staff</em>'.
	 * @see research.staff
	 * @generated
	 */
	EClass getstaff();

	/**
	 * Returns the meta object for the attribute '{@link research.staff#getStaffName <em>Staff Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Staff Name</em>'.
	 * @see research.staff#getStaffName()
	 * @see #getstaff()
	 * @generated
	 */
	EAttribute getstaff_StaffName();

	/**
	 * Returns the meta object for the '{@link research.staff#CheckCustomerReq() <em>Check Customer Req</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Customer Req</em>' operation.
	 * @see research.staff#CheckCustomerReq()
	 * @generated
	 */
	EOperation getstaff__CheckCustomerReq();

	/**
	 * Returns the meta object for the '{@link research.staff#CheckPicture() <em>Check Picture</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Picture</em>' operation.
	 * @see research.staff#CheckPicture()
	 * @generated
	 */
	EOperation getstaff__CheckPicture();

	/**
	 * Returns the meta object for class '{@link research.Camera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Camera</em>'.
	 * @see research.Camera
	 * @generated
	 */
	EClass getCamera();

	/**
	 * Returns the meta object for the attribute '{@link research.Camera#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Camera</em>'.
	 * @see research.Camera#getCamera()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Camera();

	/**
	 * Returns the meta object for the attribute '{@link research.Camera#getResolution <em>Resolution</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Resolution</em>'.
	 * @see research.Camera#getResolution()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Resolution();

	/**
	 * Returns the meta object for the reference list '{@link research.Camera#getPicture <em>Picture</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Picture</em>'.
	 * @see research.Camera#getPicture()
	 * @see #getCamera()
	 * @generated
	 */
	EReference getCamera_Picture();

	/**
	 * Returns the meta object for the reference list '{@link research.Camera#getFilters <em>Filters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Filters</em>'.
	 * @see research.Camera#getFilters()
	 * @see #getCamera()
	 * @generated
	 */
	EReference getCamera_Filters();

	/**
	 * Returns the meta object for class '{@link research.EyesFilter <em>Eyes Filter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Eyes Filter</em>'.
	 * @see research.EyesFilter
	 * @generated
	 */
	EClass getEyesFilter();

	/**
	 * Returns the meta object for class '{@link research.LipFilter <em>Lip Filter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Lip Filter</em>'.
	 * @see research.LipFilter
	 * @generated
	 */
	EClass getLipFilter();

	/**
	 * Returns the meta object for class '{@link research.FullMakeUp <em>Full Make Up</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Full Make Up</em>'.
	 * @see research.FullMakeUp
	 * @generated
	 */
	EClass getFullMakeUp();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ResearchFactory getResearchFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link research.impl.MobileScreenImpl <em>Mobile Screen</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research.impl.MobileScreenImpl
		 * @see research.impl.ResearchPackageImpl#getMobileScreen()
		 * @generated
		 */
		EClass MOBILE_SCREEN = eINSTANCE.getMobileScreen();

		/**
		 * The meta object literal for the '<em><b>Productinformation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILE_SCREEN__PRODUCTINFORMATION = eINSTANCE.getMobileScreen_Productinformation();

		/**
		 * The meta object literal for the '<em><b>Camera</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILE_SCREEN__CAMERA = eINSTANCE.getMobileScreen_Camera();

		/**
		 * The meta object literal for the '<em><b>Staff</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILE_SCREEN__STAFF = eINSTANCE.getMobileScreen_Staff();

		/**
		 * The meta object literal for the '<em><b>Filters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILE_SCREEN__FILTERS = eINSTANCE.getMobileScreen_Filters();

		/**
		 * The meta object literal for the '<em><b>Picture</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILE_SCREEN__PICTURE = eINSTANCE.getMobileScreen_Picture();

		/**
		 * The meta object literal for the '{@link research.impl.FiltersImpl <em>Filters</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research.impl.FiltersImpl
		 * @see research.impl.ResearchPackageImpl#getFilters()
		 * @generated
		 */
		EClass FILTERS = eINSTANCE.getFilters();

		/**
		 * The meta object literal for the '<em><b>Filtername</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FILTERS__FILTERNAME = eINSTANCE.getFilters_Filtername();

		/**
		 * The meta object literal for the '<em><b>Productinformation</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FILTERS__PRODUCTINFORMATION = eINSTANCE.getFilters_Productinformation();

		/**
		 * The meta object literal for the '<em><b>Camera</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FILTERS__CAMERA = eINSTANCE.getFilters_Camera();

		/**
		 * The meta object literal for the '<em><b>Try Filter</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FILTERS___TRY_FILTER = eINSTANCE.getFilters__TryFilter();

		/**
		 * The meta object literal for the '{@link research.impl.productInformationImpl <em>product Information</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research.impl.productInformationImpl
		 * @see research.impl.ResearchPackageImpl#getproductInformation()
		 * @generated
		 */
		EClass PRODUCT_INFORMATION = eINSTANCE.getproductInformation();

		/**
		 * The meta object literal for the '<em><b>Brand</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT_INFORMATION__BRAND = eINSTANCE.getproductInformation_Brand();

		/**
		 * The meta object literal for the '<em><b>Foundationcolor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT_INFORMATION__FOUNDATIONCOLOR = eINSTANCE.getproductInformation_Foundationcolor();

		/**
		 * The meta object literal for the '<em><b>Lipstickcolor</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT_INFORMATION__LIPSTICKCOLOR = eINSTANCE.getproductInformation_Lipstickcolor();

		/**
		 * The meta object literal for the '<em><b>Price</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT_INFORMATION__PRICE = eINSTANCE.getproductInformation_Price();

		/**
		 * The meta object literal for the '<em><b>Filters</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PRODUCT_INFORMATION__FILTERS = eINSTANCE.getproductInformation_Filters();

		/**
		 * The meta object literal for the '{@link research.impl.PictureImpl <em>Picture</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research.impl.PictureImpl
		 * @see research.impl.ResearchPackageImpl#getPicture()
		 * @generated
		 */
		EClass PICTURE = eINSTANCE.getPicture();

		/**
		 * The meta object literal for the '<em><b>Send Pictures</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PICTURE__SEND_PICTURES = eINSTANCE.getPicture_SendPictures();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PICTURE__NAME = eINSTANCE.getPicture_Name();

		/**
		 * The meta object literal for the '<em><b>Click Picture</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PICTURE___CLICK_PICTURE = eINSTANCE.getPicture__ClickPicture();

		/**
		 * The meta object literal for the '<em><b>Save</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PICTURE___SAVE = eINSTANCE.getPicture__Save();

		/**
		 * The meta object literal for the '<em><b>Send</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PICTURE___SEND = eINSTANCE.getPicture__Send();

		/**
		 * The meta object literal for the '{@link research.impl.staffImpl <em>staff</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research.impl.staffImpl
		 * @see research.impl.ResearchPackageImpl#getstaff()
		 * @generated
		 */
		EClass STAFF = eINSTANCE.getstaff();

		/**
		 * The meta object literal for the '<em><b>Staff Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STAFF__STAFF_NAME = eINSTANCE.getstaff_StaffName();

		/**
		 * The meta object literal for the '<em><b>Check Customer Req</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STAFF___CHECK_CUSTOMER_REQ = eINSTANCE.getstaff__CheckCustomerReq();

		/**
		 * The meta object literal for the '<em><b>Check Picture</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STAFF___CHECK_PICTURE = eINSTANCE.getstaff__CheckPicture();

		/**
		 * The meta object literal for the '{@link research.impl.CameraImpl <em>Camera</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research.impl.CameraImpl
		 * @see research.impl.ResearchPackageImpl#getCamera()
		 * @generated
		 */
		EClass CAMERA = eINSTANCE.getCamera();

		/**
		 * The meta object literal for the '<em><b>Camera</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__CAMERA = eINSTANCE.getCamera_Camera();

		/**
		 * The meta object literal for the '<em><b>Resolution</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__RESOLUTION = eINSTANCE.getCamera_Resolution();

		/**
		 * The meta object literal for the '<em><b>Picture</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CAMERA__PICTURE = eINSTANCE.getCamera_Picture();

		/**
		 * The meta object literal for the '<em><b>Filters</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CAMERA__FILTERS = eINSTANCE.getCamera_Filters();

		/**
		 * The meta object literal for the '{@link research.impl.EyesFilterImpl <em>Eyes Filter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research.impl.EyesFilterImpl
		 * @see research.impl.ResearchPackageImpl#getEyesFilter()
		 * @generated
		 */
		EClass EYES_FILTER = eINSTANCE.getEyesFilter();

		/**
		 * The meta object literal for the '{@link research.impl.LipFilterImpl <em>Lip Filter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research.impl.LipFilterImpl
		 * @see research.impl.ResearchPackageImpl#getLipFilter()
		 * @generated
		 */
		EClass LIP_FILTER = eINSTANCE.getLipFilter();

		/**
		 * The meta object literal for the '{@link research.impl.FullMakeUpImpl <em>Full Make Up</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see research.impl.FullMakeUpImpl
		 * @see research.impl.ResearchPackageImpl#getFullMakeUp()
		 * @generated
		 */
		EClass FULL_MAKE_UP = eINSTANCE.getFullMakeUp();

	}

} //ResearchPackage
