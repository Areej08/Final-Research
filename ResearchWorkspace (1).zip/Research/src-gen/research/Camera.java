/**
 */
package research;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Camera</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research.Camera#getCamera <em>Camera</em>}</li>
 *   <li>{@link research.Camera#getResolution <em>Resolution</em>}</li>
 *   <li>{@link research.Camera#getPicture <em>Picture</em>}</li>
 *   <li>{@link research.Camera#getFilters <em>Filters</em>}</li>
 * </ul>
 *
 * @see research.ResearchPackage#getCamera()
 * @model
 * @generated
 */
public interface Camera extends EObject {
	/**
	 * Returns the value of the '<em><b>Camera</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Camera</em>' attribute.
	 * @see #setCamera(String)
	 * @see research.ResearchPackage#getCamera_Camera()
	 * @model
	 * @generated
	 */
	String getCamera();

	/**
	 * Sets the value of the '{@link research.Camera#getCamera <em>Camera</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Camera</em>' attribute.
	 * @see #getCamera()
	 * @generated
	 */
	void setCamera(String value);

	/**
	 * Returns the value of the '<em><b>Resolution</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Resolution</em>' attribute.
	 * @see #setResolution(String)
	 * @see research.ResearchPackage#getCamera_Resolution()
	 * @model default=""
	 * @generated
	 */
	String getResolution();

	/**
	 * Sets the value of the '{@link research.Camera#getResolution <em>Resolution</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Resolution</em>' attribute.
	 * @see #getResolution()
	 * @generated
	 */
	void setResolution(String value);

	/**
	 * Returns the value of the '<em><b>Picture</b></em>' reference list.
	 * The list contents are of type {@link research.Picture}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Picture</em>' reference list.
	 * @see research.ResearchPackage#getCamera_Picture()
	 * @model
	 * @generated
	 */
	EList<Picture> getPicture();

	/**
	 * Returns the value of the '<em><b>Filters</b></em>' reference list.
	 * The list contents are of type {@link research.Filters}.
	 * It is bidirectional and its opposite is '{@link research.Filters#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Filters</em>' reference list.
	 * @see research.ResearchPackage#getCamera_Filters()
	 * @see research.Filters#getCamera
	 * @model opposite="camera"
	 * @generated
	 */
	EList<Filters> getFilters();

} // Camera
