/**
 */
package research;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Eyes Filter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see research.ResearchPackage#getEyesFilter()
 * @model
 * @generated
 */
public interface EyesFilter extends Filters {
} // EyesFilter
