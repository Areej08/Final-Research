/**
 */
package research;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mobile Screen</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research.MobileScreen#getProductinformation <em>Productinformation</em>}</li>
 *   <li>{@link research.MobileScreen#getCamera <em>Camera</em>}</li>
 *   <li>{@link research.MobileScreen#getStaff <em>Staff</em>}</li>
 *   <li>{@link research.MobileScreen#getFilters <em>Filters</em>}</li>
 *   <li>{@link research.MobileScreen#getPicture <em>Picture</em>}</li>
 * </ul>
 *
 * @see research.ResearchPackage#getMobileScreen()
 * @model
 * @generated
 */
public interface MobileScreen extends EObject {
	/**
	 * Returns the value of the '<em><b>Productinformation</b></em>' containment reference list.
	 * The list contents are of type {@link research.productInformation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Productinformation</em>' containment reference list.
	 * @see research.ResearchPackage#getMobileScreen_Productinformation()
	 * @model containment="true"
	 * @generated
	 */
	EList<productInformation> getProductinformation();

	/**
	 * Returns the value of the '<em><b>Camera</b></em>' containment reference list.
	 * The list contents are of type {@link research.Camera}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Camera</em>' containment reference list.
	 * @see research.ResearchPackage#getMobileScreen_Camera()
	 * @model containment="true"
	 * @generated
	 */
	EList<Camera> getCamera();

	/**
	 * Returns the value of the '<em><b>Staff</b></em>' containment reference list.
	 * The list contents are of type {@link research.staff}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Staff</em>' containment reference list.
	 * @see research.ResearchPackage#getMobileScreen_Staff()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<staff> getStaff();

	/**
	 * Returns the value of the '<em><b>Filters</b></em>' containment reference list.
	 * The list contents are of type {@link research.Filters}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Filters</em>' containment reference list.
	 * @see research.ResearchPackage#getMobileScreen_Filters()
	 * @model containment="true"
	 * @generated
	 */
	EList<Filters> getFilters();

	/**
	 * Returns the value of the '<em><b>Picture</b></em>' containment reference list.
	 * The list contents are of type {@link research.Picture}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Picture</em>' containment reference list.
	 * @see research.ResearchPackage#getMobileScreen_Picture()
	 * @model containment="true"
	 * @generated
	 */
	EList<Picture> getPicture();

} // MobileScreen
