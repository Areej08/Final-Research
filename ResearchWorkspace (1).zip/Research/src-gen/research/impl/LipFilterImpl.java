/**
 */
package research.impl;

import org.eclipse.emf.ecore.EClass;

import research.LipFilter;
import research.ResearchPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Lip Filter</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LipFilterImpl extends FiltersImpl implements LipFilter {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LipFilterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ResearchPackage.Literals.LIP_FILTER;
	}

} //LipFilterImpl
