/**
 */
package research.impl;

import org.eclipse.emf.ecore.EClass;

import research.EyesFilter;
import research.ResearchPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Eyes Filter</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EyesFilterImpl extends FiltersImpl implements EyesFilter {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EyesFilterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ResearchPackage.Literals.EYES_FILTER;
	}

} //EyesFilterImpl
