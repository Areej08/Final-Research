/**
 */
package research.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import research.Camera;
import research.Filters;
import research.MobileScreen;
import research.Picture;
import research.ResearchPackage;
import research.productInformation;
import research.staff;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mobile Screen</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research.impl.MobileScreenImpl#getProductinformation <em>Productinformation</em>}</li>
 *   <li>{@link research.impl.MobileScreenImpl#getCamera <em>Camera</em>}</li>
 *   <li>{@link research.impl.MobileScreenImpl#getStaff <em>Staff</em>}</li>
 *   <li>{@link research.impl.MobileScreenImpl#getFilters <em>Filters</em>}</li>
 *   <li>{@link research.impl.MobileScreenImpl#getPicture <em>Picture</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MobileScreenImpl extends MinimalEObjectImpl.Container implements MobileScreen {
	/**
	 * The cached value of the '{@link #getProductinformation() <em>Productinformation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductinformation()
	 * @generated
	 * @ordered
	 */
	protected EList<productInformation> productinformation;

	/**
	 * The cached value of the '{@link #getCamera() <em>Camera</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCamera()
	 * @generated
	 * @ordered
	 */
	protected EList<Camera> camera;

	/**
	 * The cached value of the '{@link #getStaff() <em>Staff</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaff()
	 * @generated
	 * @ordered
	 */
	protected EList<staff> staff;

	/**
	 * The cached value of the '{@link #getFilters() <em>Filters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFilters()
	 * @generated
	 * @ordered
	 */
	protected EList<Filters> filters;

	/**
	 * The cached value of the '{@link #getPicture() <em>Picture</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPicture()
	 * @generated
	 * @ordered
	 */
	protected EList<Picture> picture;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MobileScreenImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ResearchPackage.Literals.MOBILE_SCREEN;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<productInformation> getProductinformation() {
		if (productinformation == null) {
			productinformation = new EObjectContainmentEList<productInformation>(productInformation.class, this,
					ResearchPackage.MOBILE_SCREEN__PRODUCTINFORMATION);
		}
		return productinformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Camera> getCamera() {
		if (camera == null) {
			camera = new EObjectContainmentEList<Camera>(Camera.class, this, ResearchPackage.MOBILE_SCREEN__CAMERA);
		}
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<staff> getStaff() {
		if (staff == null) {
			staff = new EObjectContainmentEList<staff>(staff.class, this, ResearchPackage.MOBILE_SCREEN__STAFF);
		}
		return staff;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Filters> getFilters() {
		if (filters == null) {
			filters = new EObjectContainmentEList<Filters>(Filters.class, this, ResearchPackage.MOBILE_SCREEN__FILTERS);
		}
		return filters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Picture> getPicture() {
		if (picture == null) {
			picture = new EObjectContainmentEList<Picture>(Picture.class, this, ResearchPackage.MOBILE_SCREEN__PICTURE);
		}
		return picture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ResearchPackage.MOBILE_SCREEN__PRODUCTINFORMATION:
			return ((InternalEList<?>) getProductinformation()).basicRemove(otherEnd, msgs);
		case ResearchPackage.MOBILE_SCREEN__CAMERA:
			return ((InternalEList<?>) getCamera()).basicRemove(otherEnd, msgs);
		case ResearchPackage.MOBILE_SCREEN__STAFF:
			return ((InternalEList<?>) getStaff()).basicRemove(otherEnd, msgs);
		case ResearchPackage.MOBILE_SCREEN__FILTERS:
			return ((InternalEList<?>) getFilters()).basicRemove(otherEnd, msgs);
		case ResearchPackage.MOBILE_SCREEN__PICTURE:
			return ((InternalEList<?>) getPicture()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ResearchPackage.MOBILE_SCREEN__PRODUCTINFORMATION:
			return getProductinformation();
		case ResearchPackage.MOBILE_SCREEN__CAMERA:
			return getCamera();
		case ResearchPackage.MOBILE_SCREEN__STAFF:
			return getStaff();
		case ResearchPackage.MOBILE_SCREEN__FILTERS:
			return getFilters();
		case ResearchPackage.MOBILE_SCREEN__PICTURE:
			return getPicture();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ResearchPackage.MOBILE_SCREEN__PRODUCTINFORMATION:
			getProductinformation().clear();
			getProductinformation().addAll((Collection<? extends productInformation>) newValue);
			return;
		case ResearchPackage.MOBILE_SCREEN__CAMERA:
			getCamera().clear();
			getCamera().addAll((Collection<? extends Camera>) newValue);
			return;
		case ResearchPackage.MOBILE_SCREEN__STAFF:
			getStaff().clear();
			getStaff().addAll((Collection<? extends staff>) newValue);
			return;
		case ResearchPackage.MOBILE_SCREEN__FILTERS:
			getFilters().clear();
			getFilters().addAll((Collection<? extends Filters>) newValue);
			return;
		case ResearchPackage.MOBILE_SCREEN__PICTURE:
			getPicture().clear();
			getPicture().addAll((Collection<? extends Picture>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ResearchPackage.MOBILE_SCREEN__PRODUCTINFORMATION:
			getProductinformation().clear();
			return;
		case ResearchPackage.MOBILE_SCREEN__CAMERA:
			getCamera().clear();
			return;
		case ResearchPackage.MOBILE_SCREEN__STAFF:
			getStaff().clear();
			return;
		case ResearchPackage.MOBILE_SCREEN__FILTERS:
			getFilters().clear();
			return;
		case ResearchPackage.MOBILE_SCREEN__PICTURE:
			getPicture().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ResearchPackage.MOBILE_SCREEN__PRODUCTINFORMATION:
			return productinformation != null && !productinformation.isEmpty();
		case ResearchPackage.MOBILE_SCREEN__CAMERA:
			return camera != null && !camera.isEmpty();
		case ResearchPackage.MOBILE_SCREEN__STAFF:
			return staff != null && !staff.isEmpty();
		case ResearchPackage.MOBILE_SCREEN__FILTERS:
			return filters != null && !filters.isEmpty();
		case ResearchPackage.MOBILE_SCREEN__PICTURE:
			return picture != null && !picture.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //MobileScreenImpl
