/**
 */
package research.impl;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import research.Camera;
import research.Filters;
import research.ResearchPackage;
import research.productInformation;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Filters</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research.impl.FiltersImpl#getFiltername <em>Filtername</em>}</li>
 *   <li>{@link research.impl.FiltersImpl#getProductinformation <em>Productinformation</em>}</li>
 *   <li>{@link research.impl.FiltersImpl#getCamera <em>Camera</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class FiltersImpl extends MinimalEObjectImpl.Container implements Filters {
	/**
	 * The default value of the '{@link #getFiltername() <em>Filtername</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFiltername()
	 * @generated
	 * @ordered
	 */
	protected static final String FILTERNAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFiltername() <em>Filtername</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFiltername()
	 * @generated
	 * @ordered
	 */
	protected String filtername = FILTERNAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getProductinformation() <em>Productinformation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductinformation()
	 * @generated
	 * @ordered
	 */
	protected productInformation productinformation;

	/**
	 * The cached value of the '{@link #getCamera() <em>Camera</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCamera()
	 * @generated
	 * @ordered
	 */
	protected Camera camera;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FiltersImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ResearchPackage.Literals.FILTERS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getFiltername() {
		return filtername;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFiltername(String newFiltername) {
		String oldFiltername = filtername;
		filtername = newFiltername;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ResearchPackage.FILTERS__FILTERNAME, oldFiltername,
					filtername));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public productInformation getProductinformation() {
		if (productinformation != null && productinformation.eIsProxy()) {
			InternalEObject oldProductinformation = (InternalEObject) productinformation;
			productinformation = (productInformation) eResolveProxy(oldProductinformation);
			if (productinformation != oldProductinformation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ResearchPackage.FILTERS__PRODUCTINFORMATION, oldProductinformation, productinformation));
			}
		}
		return productinformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public productInformation basicGetProductinformation() {
		return productinformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetProductinformation(productInformation newProductinformation,
			NotificationChain msgs) {
		productInformation oldProductinformation = productinformation;
		productinformation = newProductinformation;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					ResearchPackage.FILTERS__PRODUCTINFORMATION, oldProductinformation, newProductinformation);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setProductinformation(productInformation newProductinformation) {
		if (newProductinformation != productinformation) {
			NotificationChain msgs = null;
			if (productinformation != null)
				msgs = ((InternalEObject) productinformation).eInverseRemove(this,
						ResearchPackage.PRODUCT_INFORMATION__FILTERS, productInformation.class, msgs);
			if (newProductinformation != null)
				msgs = ((InternalEObject) newProductinformation).eInverseAdd(this,
						ResearchPackage.PRODUCT_INFORMATION__FILTERS, productInformation.class, msgs);
			msgs = basicSetProductinformation(newProductinformation, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ResearchPackage.FILTERS__PRODUCTINFORMATION,
					newProductinformation, newProductinformation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Camera getCamera() {
		if (camera != null && camera.eIsProxy()) {
			InternalEObject oldCamera = (InternalEObject) camera;
			camera = (Camera) eResolveProxy(oldCamera);
			if (camera != oldCamera) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ResearchPackage.FILTERS__CAMERA,
							oldCamera, camera));
			}
		}
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Camera basicGetCamera() {
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCamera(Camera newCamera, NotificationChain msgs) {
		Camera oldCamera = camera;
		camera = newCamera;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					ResearchPackage.FILTERS__CAMERA, oldCamera, newCamera);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCamera(Camera newCamera) {
		if (newCamera != camera) {
			NotificationChain msgs = null;
			if (camera != null)
				msgs = ((InternalEObject) camera).eInverseRemove(this, ResearchPackage.CAMERA__FILTERS, Camera.class,
						msgs);
			if (newCamera != null)
				msgs = ((InternalEObject) newCamera).eInverseAdd(this, ResearchPackage.CAMERA__FILTERS, Camera.class,
						msgs);
			msgs = basicSetCamera(newCamera, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ResearchPackage.FILTERS__CAMERA, newCamera,
					newCamera));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void tryFilter() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ResearchPackage.FILTERS__PRODUCTINFORMATION:
			if (productinformation != null)
				msgs = ((InternalEObject) productinformation).eInverseRemove(this,
						ResearchPackage.PRODUCT_INFORMATION__FILTERS, productInformation.class, msgs);
			return basicSetProductinformation((productInformation) otherEnd, msgs);
		case ResearchPackage.FILTERS__CAMERA:
			if (camera != null)
				msgs = ((InternalEObject) camera).eInverseRemove(this, ResearchPackage.CAMERA__FILTERS, Camera.class,
						msgs);
			return basicSetCamera((Camera) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ResearchPackage.FILTERS__PRODUCTINFORMATION:
			return basicSetProductinformation(null, msgs);
		case ResearchPackage.FILTERS__CAMERA:
			return basicSetCamera(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ResearchPackage.FILTERS__FILTERNAME:
			return getFiltername();
		case ResearchPackage.FILTERS__PRODUCTINFORMATION:
			if (resolve)
				return getProductinformation();
			return basicGetProductinformation();
		case ResearchPackage.FILTERS__CAMERA:
			if (resolve)
				return getCamera();
			return basicGetCamera();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ResearchPackage.FILTERS__FILTERNAME:
			setFiltername((String) newValue);
			return;
		case ResearchPackage.FILTERS__PRODUCTINFORMATION:
			setProductinformation((productInformation) newValue);
			return;
		case ResearchPackage.FILTERS__CAMERA:
			setCamera((Camera) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ResearchPackage.FILTERS__FILTERNAME:
			setFiltername(FILTERNAME_EDEFAULT);
			return;
		case ResearchPackage.FILTERS__PRODUCTINFORMATION:
			setProductinformation((productInformation) null);
			return;
		case ResearchPackage.FILTERS__CAMERA:
			setCamera((Camera) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ResearchPackage.FILTERS__FILTERNAME:
			return FILTERNAME_EDEFAULT == null ? filtername != null : !FILTERNAME_EDEFAULT.equals(filtername);
		case ResearchPackage.FILTERS__PRODUCTINFORMATION:
			return productinformation != null;
		case ResearchPackage.FILTERS__CAMERA:
			return camera != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case ResearchPackage.FILTERS___TRY_FILTER:
			tryFilter();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Filtername: ");
		result.append(filtername);
		result.append(')');
		return result.toString();
	}

} //FiltersImpl
