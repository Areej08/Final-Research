/**
 */
package research.impl;

import org.eclipse.emf.ecore.EClass;

import research.FullMakeUp;
import research.ResearchPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Full Make Up</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FullMakeUpImpl extends FiltersImpl implements FullMakeUp {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FullMakeUpImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ResearchPackage.Literals.FULL_MAKE_UP;
	}

} //FullMakeUpImpl
