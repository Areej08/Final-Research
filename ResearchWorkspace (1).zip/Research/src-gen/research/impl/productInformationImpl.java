/**
 */
package research.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import research.Filters;
import research.ResearchPackage;
import research.productInformation;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>product Information</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research.impl.productInformationImpl#getBrand <em>Brand</em>}</li>
 *   <li>{@link research.impl.productInformationImpl#getFoundationcolor <em>Foundationcolor</em>}</li>
 *   <li>{@link research.impl.productInformationImpl#getLipstickcolor <em>Lipstickcolor</em>}</li>
 *   <li>{@link research.impl.productInformationImpl#getPrice <em>Price</em>}</li>
 *   <li>{@link research.impl.productInformationImpl#getFilters <em>Filters</em>}</li>
 * </ul>
 *
 * @generated
 */
public class productInformationImpl extends MinimalEObjectImpl.Container implements productInformation {
	/**
	 * The default value of the '{@link #getBrand() <em>Brand</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBrand()
	 * @generated
	 * @ordered
	 */
	protected static final String BRAND_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBrand() <em>Brand</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBrand()
	 * @generated
	 * @ordered
	 */
	protected String brand = BRAND_EDEFAULT;

	/**
	 * The default value of the '{@link #getFoundationcolor() <em>Foundationcolor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFoundationcolor()
	 * @generated
	 * @ordered
	 */
	protected static final String FOUNDATIONCOLOR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFoundationcolor() <em>Foundationcolor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFoundationcolor()
	 * @generated
	 * @ordered
	 */
	protected String foundationcolor = FOUNDATIONCOLOR_EDEFAULT;

	/**
	 * The default value of the '{@link #getLipstickcolor() <em>Lipstickcolor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLipstickcolor()
	 * @generated
	 * @ordered
	 */
	protected static final String LIPSTICKCOLOR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLipstickcolor() <em>Lipstickcolor</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLipstickcolor()
	 * @generated
	 * @ordered
	 */
	protected String lipstickcolor = LIPSTICKCOLOR_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected static final int PRICE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected int price = PRICE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getFilters() <em>Filters</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFilters()
	 * @generated
	 * @ordered
	 */
	protected Filters filters;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected productInformationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ResearchPackage.Literals.PRODUCT_INFORMATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getBrand() {
		return brand;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBrand(String newBrand) {
		String oldBrand = brand;
		brand = newBrand;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ResearchPackage.PRODUCT_INFORMATION__BRAND, oldBrand,
					brand));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getFoundationcolor() {
		return foundationcolor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFoundationcolor(String newFoundationcolor) {
		String oldFoundationcolor = foundationcolor;
		foundationcolor = newFoundationcolor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ResearchPackage.PRODUCT_INFORMATION__FOUNDATIONCOLOR,
					oldFoundationcolor, foundationcolor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLipstickcolor() {
		return lipstickcolor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLipstickcolor(String newLipstickcolor) {
		String oldLipstickcolor = lipstickcolor;
		lipstickcolor = newLipstickcolor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ResearchPackage.PRODUCT_INFORMATION__LIPSTICKCOLOR,
					oldLipstickcolor, lipstickcolor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getPrice() {
		return price;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPrice(int newPrice) {
		int oldPrice = price;
		price = newPrice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ResearchPackage.PRODUCT_INFORMATION__PRICE, oldPrice,
					price));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Filters getFilters() {
		if (filters != null && filters.eIsProxy()) {
			InternalEObject oldFilters = (InternalEObject) filters;
			filters = (Filters) eResolveProxy(oldFilters);
			if (filters != oldFilters) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ResearchPackage.PRODUCT_INFORMATION__FILTERS, oldFilters, filters));
			}
		}
		return filters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Filters basicGetFilters() {
		return filters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFilters(Filters newFilters, NotificationChain msgs) {
		Filters oldFilters = filters;
		filters = newFilters;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					ResearchPackage.PRODUCT_INFORMATION__FILTERS, oldFilters, newFilters);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFilters(Filters newFilters) {
		if (newFilters != filters) {
			NotificationChain msgs = null;
			if (filters != null)
				msgs = ((InternalEObject) filters).eInverseRemove(this, ResearchPackage.FILTERS__PRODUCTINFORMATION,
						Filters.class, msgs);
			if (newFilters != null)
				msgs = ((InternalEObject) newFilters).eInverseAdd(this, ResearchPackage.FILTERS__PRODUCTINFORMATION,
						Filters.class, msgs);
			msgs = basicSetFilters(newFilters, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ResearchPackage.PRODUCT_INFORMATION__FILTERS,
					newFilters, newFilters));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ResearchPackage.PRODUCT_INFORMATION__FILTERS:
			if (filters != null)
				msgs = ((InternalEObject) filters).eInverseRemove(this, ResearchPackage.FILTERS__PRODUCTINFORMATION,
						Filters.class, msgs);
			return basicSetFilters((Filters) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ResearchPackage.PRODUCT_INFORMATION__FILTERS:
			return basicSetFilters(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ResearchPackage.PRODUCT_INFORMATION__BRAND:
			return getBrand();
		case ResearchPackage.PRODUCT_INFORMATION__FOUNDATIONCOLOR:
			return getFoundationcolor();
		case ResearchPackage.PRODUCT_INFORMATION__LIPSTICKCOLOR:
			return getLipstickcolor();
		case ResearchPackage.PRODUCT_INFORMATION__PRICE:
			return getPrice();
		case ResearchPackage.PRODUCT_INFORMATION__FILTERS:
			if (resolve)
				return getFilters();
			return basicGetFilters();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ResearchPackage.PRODUCT_INFORMATION__BRAND:
			setBrand((String) newValue);
			return;
		case ResearchPackage.PRODUCT_INFORMATION__FOUNDATIONCOLOR:
			setFoundationcolor((String) newValue);
			return;
		case ResearchPackage.PRODUCT_INFORMATION__LIPSTICKCOLOR:
			setLipstickcolor((String) newValue);
			return;
		case ResearchPackage.PRODUCT_INFORMATION__PRICE:
			setPrice((Integer) newValue);
			return;
		case ResearchPackage.PRODUCT_INFORMATION__FILTERS:
			setFilters((Filters) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ResearchPackage.PRODUCT_INFORMATION__BRAND:
			setBrand(BRAND_EDEFAULT);
			return;
		case ResearchPackage.PRODUCT_INFORMATION__FOUNDATIONCOLOR:
			setFoundationcolor(FOUNDATIONCOLOR_EDEFAULT);
			return;
		case ResearchPackage.PRODUCT_INFORMATION__LIPSTICKCOLOR:
			setLipstickcolor(LIPSTICKCOLOR_EDEFAULT);
			return;
		case ResearchPackage.PRODUCT_INFORMATION__PRICE:
			setPrice(PRICE_EDEFAULT);
			return;
		case ResearchPackage.PRODUCT_INFORMATION__FILTERS:
			setFilters((Filters) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ResearchPackage.PRODUCT_INFORMATION__BRAND:
			return BRAND_EDEFAULT == null ? brand != null : !BRAND_EDEFAULT.equals(brand);
		case ResearchPackage.PRODUCT_INFORMATION__FOUNDATIONCOLOR:
			return FOUNDATIONCOLOR_EDEFAULT == null ? foundationcolor != null
					: !FOUNDATIONCOLOR_EDEFAULT.equals(foundationcolor);
		case ResearchPackage.PRODUCT_INFORMATION__LIPSTICKCOLOR:
			return LIPSTICKCOLOR_EDEFAULT == null ? lipstickcolor != null
					: !LIPSTICKCOLOR_EDEFAULT.equals(lipstickcolor);
		case ResearchPackage.PRODUCT_INFORMATION__PRICE:
			return price != PRICE_EDEFAULT;
		case ResearchPackage.PRODUCT_INFORMATION__FILTERS:
			return filters != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Brand: ");
		result.append(brand);
		result.append(", Foundationcolor: ");
		result.append(foundationcolor);
		result.append(", Lipstickcolor: ");
		result.append(lipstickcolor);
		result.append(", Price: ");
		result.append(price);
		result.append(')');
		return result.toString();
	}

} //productInformationImpl
