/**
 */
package research.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import research.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ResearchFactoryImpl extends EFactoryImpl implements ResearchFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ResearchFactory init() {
		try {
			ResearchFactory theResearchFactory = (ResearchFactory) EPackage.Registry.INSTANCE
					.getEFactory(ResearchPackage.eNS_URI);
			if (theResearchFactory != null) {
				return theResearchFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ResearchFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ResearchFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ResearchPackage.MOBILE_SCREEN:
			return createMobileScreen();
		case ResearchPackage.PRODUCT_INFORMATION:
			return createproductInformation();
		case ResearchPackage.PICTURE:
			return createPicture();
		case ResearchPackage.STAFF:
			return createstaff();
		case ResearchPackage.CAMERA:
			return createCamera();
		case ResearchPackage.EYES_FILTER:
			return createEyesFilter();
		case ResearchPackage.LIP_FILTER:
			return createLipFilter();
		case ResearchPackage.FULL_MAKE_UP:
			return createFullMakeUp();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MobileScreen createMobileScreen() {
		MobileScreenImpl mobileScreen = new MobileScreenImpl();
		return mobileScreen;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public productInformation createproductInformation() {
		productInformationImpl productInformation = new productInformationImpl();
		return productInformation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Picture createPicture() {
		PictureImpl picture = new PictureImpl();
		return picture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public staff createstaff() {
		staffImpl staff = new staffImpl();
		return staff;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Camera createCamera() {
		CameraImpl camera = new CameraImpl();
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EyesFilter createEyesFilter() {
		EyesFilterImpl eyesFilter = new EyesFilterImpl();
		return eyesFilter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public LipFilter createLipFilter() {
		LipFilterImpl lipFilter = new LipFilterImpl();
		return lipFilter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FullMakeUp createFullMakeUp() {
		FullMakeUpImpl fullMakeUp = new FullMakeUpImpl();
		return fullMakeUp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResearchPackage getResearchPackage() {
		return (ResearchPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ResearchPackage getPackage() {
		return ResearchPackage.eINSTANCE;
	}

} //ResearchFactoryImpl
