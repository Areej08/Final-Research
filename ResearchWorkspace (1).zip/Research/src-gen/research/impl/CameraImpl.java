/**
 */
package research.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
import research.Camera;
import research.Filters;
import research.Picture;
import research.ResearchPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Camera</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link research.impl.CameraImpl#getCamera <em>Camera</em>}</li>
 *   <li>{@link research.impl.CameraImpl#getResolution <em>Resolution</em>}</li>
 *   <li>{@link research.impl.CameraImpl#getPicture <em>Picture</em>}</li>
 *   <li>{@link research.impl.CameraImpl#getFilters <em>Filters</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CameraImpl extends MinimalEObjectImpl.Container implements Camera {
	/**
	 * The default value of the '{@link #getCamera() <em>Camera</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCamera()
	 * @generated
	 * @ordered
	 */
	protected static final String CAMERA_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCamera() <em>Camera</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCamera()
	 * @generated
	 * @ordered
	 */
	protected String camera = CAMERA_EDEFAULT;

	/**
	 * The default value of the '{@link #getResolution() <em>Resolution</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResolution()
	 * @generated
	 * @ordered
	 */
	protected static final String RESOLUTION_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getResolution() <em>Resolution</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResolution()
	 * @generated
	 * @ordered
	 */
	protected String resolution = RESOLUTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPicture() <em>Picture</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPicture()
	 * @generated
	 * @ordered
	 */
	protected EList<Picture> picture;

	/**
	 * The cached value of the '{@link #getFilters() <em>Filters</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFilters()
	 * @generated
	 * @ordered
	 */
	protected EList<Filters> filters;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CameraImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ResearchPackage.Literals.CAMERA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getCamera() {
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCamera(String newCamera) {
		String oldCamera = camera;
		camera = newCamera;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ResearchPackage.CAMERA__CAMERA, oldCamera, camera));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getResolution() {
		return resolution;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setResolution(String newResolution) {
		String oldResolution = resolution;
		resolution = newResolution;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ResearchPackage.CAMERA__RESOLUTION, oldResolution,
					resolution));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Picture> getPicture() {
		if (picture == null) {
			picture = new EObjectResolvingEList<Picture>(Picture.class, this, ResearchPackage.CAMERA__PICTURE);
		}
		return picture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Filters> getFilters() {
		if (filters == null) {
			filters = new EObjectWithInverseResolvingEList<Filters>(Filters.class, this,
					ResearchPackage.CAMERA__FILTERS, ResearchPackage.FILTERS__CAMERA);
		}
		return filters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ResearchPackage.CAMERA__FILTERS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getFilters()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ResearchPackage.CAMERA__FILTERS:
			return ((InternalEList<?>) getFilters()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ResearchPackage.CAMERA__CAMERA:
			return getCamera();
		case ResearchPackage.CAMERA__RESOLUTION:
			return getResolution();
		case ResearchPackage.CAMERA__PICTURE:
			return getPicture();
		case ResearchPackage.CAMERA__FILTERS:
			return getFilters();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ResearchPackage.CAMERA__CAMERA:
			setCamera((String) newValue);
			return;
		case ResearchPackage.CAMERA__RESOLUTION:
			setResolution((String) newValue);
			return;
		case ResearchPackage.CAMERA__PICTURE:
			getPicture().clear();
			getPicture().addAll((Collection<? extends Picture>) newValue);
			return;
		case ResearchPackage.CAMERA__FILTERS:
			getFilters().clear();
			getFilters().addAll((Collection<? extends Filters>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ResearchPackage.CAMERA__CAMERA:
			setCamera(CAMERA_EDEFAULT);
			return;
		case ResearchPackage.CAMERA__RESOLUTION:
			setResolution(RESOLUTION_EDEFAULT);
			return;
		case ResearchPackage.CAMERA__PICTURE:
			getPicture().clear();
			return;
		case ResearchPackage.CAMERA__FILTERS:
			getFilters().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ResearchPackage.CAMERA__CAMERA:
			return CAMERA_EDEFAULT == null ? camera != null : !CAMERA_EDEFAULT.equals(camera);
		case ResearchPackage.CAMERA__RESOLUTION:
			return RESOLUTION_EDEFAULT == null ? resolution != null : !RESOLUTION_EDEFAULT.equals(resolution);
		case ResearchPackage.CAMERA__PICTURE:
			return picture != null && !picture.isEmpty();
		case ResearchPackage.CAMERA__FILTERS:
			return filters != null && !filters.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Camera: ");
		result.append(camera);
		result.append(", Resolution: ");
		result.append(resolution);
		result.append(')');
		return result.toString();
	}

} //CameraImpl
