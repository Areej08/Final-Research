/**
 */
package research.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import research.Camera;
import research.EyesFilter;
import research.Filters;
import research.FullMakeUp;
import research.LipFilter;
import research.MobileScreen;
import research.Picture;
import research.ResearchFactory;
import research.ResearchPackage;
import research.productInformation;
import research.staff;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ResearchPackageImpl extends EPackageImpl implements ResearchPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mobileScreenEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass filtersEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass productInformationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pictureEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass staffEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cameraEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass eyesFilterEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass lipFilterEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fullMakeUpEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see research.ResearchPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ResearchPackageImpl() {
		super(eNS_URI, ResearchFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link ResearchPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ResearchPackage init() {
		if (isInited)
			return (ResearchPackage) EPackage.Registry.INSTANCE.getEPackage(ResearchPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredResearchPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ResearchPackageImpl theResearchPackage = registeredResearchPackage instanceof ResearchPackageImpl
				? (ResearchPackageImpl) registeredResearchPackage
				: new ResearchPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theResearchPackage.createPackageContents();

		// Initialize created meta-data
		theResearchPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theResearchPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ResearchPackage.eNS_URI, theResearchPackage);
		return theResearchPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMobileScreen() {
		return mobileScreenEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMobileScreen_Productinformation() {
		return (EReference) mobileScreenEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMobileScreen_Camera() {
		return (EReference) mobileScreenEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMobileScreen_Staff() {
		return (EReference) mobileScreenEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMobileScreen_Filters() {
		return (EReference) mobileScreenEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMobileScreen_Picture() {
		return (EReference) mobileScreenEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFilters() {
		return filtersEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getFilters_Filtername() {
		return (EAttribute) filtersEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getFilters_Productinformation() {
		return (EReference) filtersEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getFilters_Camera() {
		return (EReference) filtersEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getFilters__TryFilter() {
		return filtersEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getproductInformation() {
		return productInformationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getproductInformation_Brand() {
		return (EAttribute) productInformationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getproductInformation_Foundationcolor() {
		return (EAttribute) productInformationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getproductInformation_Lipstickcolor() {
		return (EAttribute) productInformationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getproductInformation_Price() {
		return (EAttribute) productInformationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getproductInformation_Filters() {
		return (EReference) productInformationEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPicture() {
		return pictureEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getPicture_SendPictures() {
		return (EReference) pictureEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPicture_Name() {
		return (EAttribute) pictureEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getPicture__ClickPicture() {
		return pictureEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getPicture__Save() {
		return pictureEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getPicture__Send() {
		return pictureEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getstaff() {
		return staffEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getstaff_StaffName() {
		return (EAttribute) staffEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getstaff__CheckCustomerReq() {
		return staffEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getstaff__CheckPicture() {
		return staffEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCamera() {
		return cameraEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getCamera_Camera() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getCamera_Resolution() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCamera_Picture() {
		return (EReference) cameraEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCamera_Filters() {
		return (EReference) cameraEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getEyesFilter() {
		return eyesFilterEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLipFilter() {
		return lipFilterEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFullMakeUp() {
		return fullMakeUpEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResearchFactory getResearchFactory() {
		return (ResearchFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		mobileScreenEClass = createEClass(MOBILE_SCREEN);
		createEReference(mobileScreenEClass, MOBILE_SCREEN__PRODUCTINFORMATION);
		createEReference(mobileScreenEClass, MOBILE_SCREEN__CAMERA);
		createEReference(mobileScreenEClass, MOBILE_SCREEN__STAFF);
		createEReference(mobileScreenEClass, MOBILE_SCREEN__FILTERS);
		createEReference(mobileScreenEClass, MOBILE_SCREEN__PICTURE);

		filtersEClass = createEClass(FILTERS);
		createEAttribute(filtersEClass, FILTERS__FILTERNAME);
		createEReference(filtersEClass, FILTERS__PRODUCTINFORMATION);
		createEReference(filtersEClass, FILTERS__CAMERA);
		createEOperation(filtersEClass, FILTERS___TRY_FILTER);

		productInformationEClass = createEClass(PRODUCT_INFORMATION);
		createEAttribute(productInformationEClass, PRODUCT_INFORMATION__BRAND);
		createEAttribute(productInformationEClass, PRODUCT_INFORMATION__FOUNDATIONCOLOR);
		createEAttribute(productInformationEClass, PRODUCT_INFORMATION__LIPSTICKCOLOR);
		createEAttribute(productInformationEClass, PRODUCT_INFORMATION__PRICE);
		createEReference(productInformationEClass, PRODUCT_INFORMATION__FILTERS);

		pictureEClass = createEClass(PICTURE);
		createEReference(pictureEClass, PICTURE__SEND_PICTURES);
		createEAttribute(pictureEClass, PICTURE__NAME);
		createEOperation(pictureEClass, PICTURE___CLICK_PICTURE);
		createEOperation(pictureEClass, PICTURE___SAVE);
		createEOperation(pictureEClass, PICTURE___SEND);

		staffEClass = createEClass(STAFF);
		createEAttribute(staffEClass, STAFF__STAFF_NAME);
		createEOperation(staffEClass, STAFF___CHECK_CUSTOMER_REQ);
		createEOperation(staffEClass, STAFF___CHECK_PICTURE);

		cameraEClass = createEClass(CAMERA);
		createEAttribute(cameraEClass, CAMERA__CAMERA);
		createEAttribute(cameraEClass, CAMERA__RESOLUTION);
		createEReference(cameraEClass, CAMERA__PICTURE);
		createEReference(cameraEClass, CAMERA__FILTERS);

		eyesFilterEClass = createEClass(EYES_FILTER);

		lipFilterEClass = createEClass(LIP_FILTER);

		fullMakeUpEClass = createEClass(FULL_MAKE_UP);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		eyesFilterEClass.getESuperTypes().add(this.getFilters());
		lipFilterEClass.getESuperTypes().add(this.getFilters());
		fullMakeUpEClass.getESuperTypes().add(this.getFilters());

		// Initialize classes, features, and operations; add parameters
		initEClass(mobileScreenEClass, MobileScreen.class, "MobileScreen", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMobileScreen_Productinformation(), this.getproductInformation(), null, "productinformation",
				null, 0, -1, MobileScreen.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobileScreen_Camera(), this.getCamera(), null, "camera", null, 0, -1, MobileScreen.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobileScreen_Staff(), this.getstaff(), null, "staff", null, 1, -1, MobileScreen.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobileScreen_Filters(), this.getFilters(), null, "filters", null, 0, -1, MobileScreen.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMobileScreen_Picture(), this.getPicture(), null, "picture", null, 0, -1, MobileScreen.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(filtersEClass, Filters.class, "Filters", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getFilters_Filtername(), ecorePackage.getEString(), "Filtername", null, 0, 1, Filters.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFilters_Productinformation(), this.getproductInformation(),
				this.getproductInformation_Filters(), "productinformation", null, 0, 1, Filters.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getFilters_Camera(), this.getCamera(), this.getCamera_Filters(), "camera", null, 0, 1,
				Filters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getFilters__TryFilter(), null, "tryFilter", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(productInformationEClass, productInformation.class, "productInformation", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getproductInformation_Brand(), ecorePackage.getEString(), "Brand", null, 0, 1,
				productInformation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getproductInformation_Foundationcolor(), ecorePackage.getEString(), "Foundationcolor", null, 0,
				1, productInformation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getproductInformation_Lipstickcolor(), ecorePackage.getEString(), "Lipstickcolor", null, 0, 1,
				productInformation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getproductInformation_Price(), ecorePackage.getEInt(), "Price", null, 0, 1,
				productInformation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getproductInformation_Filters(), this.getFilters(), this.getFilters_Productinformation(),
				"filters", null, 0, 1, productInformation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(pictureEClass, Picture.class, "Picture", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPicture_SendPictures(), this.getstaff(), null, "SendPictures", null, 0, -1, Picture.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPicture_Name(), ecorePackage.getEString(), "Name", null, 0, 1, Picture.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getPicture__ClickPicture(), null, "ClickPicture", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getPicture__Save(), null, "Save", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getPicture__Send(), null, "Send", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(staffEClass, staff.class, "staff", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getstaff_StaffName(), ecorePackage.getEString(), "StaffName", null, 0, 1, staff.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getstaff__CheckCustomerReq(), null, "CheckCustomerReq", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getstaff__CheckPicture(), null, "CheckPicture", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(cameraEClass, Camera.class, "Camera", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCamera_Camera(), ecorePackage.getEString(), "Camera", null, 0, 1, Camera.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Resolution(), ecorePackage.getEString(), "Resolution", "", 0, 1, Camera.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCamera_Picture(), this.getPicture(), null, "picture", null, 0, -1, Camera.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCamera_Filters(), this.getFilters(), this.getFilters_Camera(), "filters", null, 0, -1,
				Camera.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(eyesFilterEClass, EyesFilter.class, "EyesFilter", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(lipFilterEClass, LipFilter.class, "LipFilter", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(fullMakeUpEClass, FullMakeUp.class, "FullMakeUp", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);
	}

} //ResearchPackageImpl
