/**
 */
package research;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Picture</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link research.Picture#getSendPictures <em>Send Pictures</em>}</li>
 *   <li>{@link research.Picture#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see research.ResearchPackage#getPicture()
 * @model
 * @generated
 */
public interface Picture extends EObject {
	/**
	 * Returns the value of the '<em><b>Send Pictures</b></em>' reference list.
	 * The list contents are of type {@link research.staff}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Send Pictures</em>' reference list.
	 * @see research.ResearchPackage#getPicture_SendPictures()
	 * @model
	 * @generated
	 */
	EList<staff> getSendPictures();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see research.ResearchPackage#getPicture_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link research.Picture#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void ClickPicture();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Save();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void Send();

} // Picture
