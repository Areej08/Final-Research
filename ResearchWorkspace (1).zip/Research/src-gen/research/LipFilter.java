/**
 */
package research;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lip Filter</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see research.ResearchPackage#getLipFilter()
 * @model
 * @generated
 */
public interface LipFilter extends Filters {
} // LipFilter
